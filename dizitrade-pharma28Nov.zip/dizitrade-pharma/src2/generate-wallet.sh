#!/bin/bash
# Copyright IBM Corp. All Rights Reserved.
#
# SPDX-License-Identifier: Apache-2.0 Extended by AI DIZITAL SOlution Ltd, UK
#
# Version Control 
#-------------------------------------------------------------------------------------------------------#
# Ver What Who When Why Comments 
# 0.1 generate-wallet.sh RaviChand Matangi 19-July-2020 Initial release wallet generattion
#  
#
#--------------------------------------------------------------------------------------------------------#
# This is a collection of bash functions used by different scriptso

rm -rf `wallet`

`node enrollAdmin.js`

sleep 10

`node registerUser.js`

tree wallet
