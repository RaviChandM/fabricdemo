// Simple API server buinsess and blockchain 
const express = require('express')

// Express Middleware
 const helmet = require('helmet') // creates headers that protect from attacks (security)
 const bodyParser = require('body-parser') // turns response into usable format
 const cors = require('cors')  // allows/disallows cross-site communication
 const morgan = require('morgan') // logs requests

// db Connection w/ localhosta
// use a Postgres database and knex to make queries.
// stgres-# \connect fabricexplorer
// You are now connected to database "fabricexplorer" as user "postgres".
 var db = require('knex')({
   client: 'pg',
   connection: {
       host : '127.0.0.1',
       user : 'hppoc',
   password : 'password',
   database : 'fabricexplorer'
               }
 });
// Controllers - aka, the db queries
 const main = require('./controllers/main')
//
// // App
 const app = express()

// App Middleware
 app.use(cors());
/*
 const whitelist = ['http://localhost:8080']
 const corsOptions = {
   origin: function (origin, callback) {
      if (whitelist.indexOf(origin) !== -1 || !origin) {
             callback(null, true)
                } else {
                     callback(new Error('Not allowed by CORS'))
                       }
               }
           }
*/	   
app.use(helmet())
//app.use(cors(corsOptions))
app.use(bodyParser.json())
app.use(morgan('combined')) // use 'tiny' or 'combined'
app.get('/', (req, res) => res.send('Welcome to AI-DIZITAL - Blockchian APIs - for details: Contact@ravichand.m@aidizital.com'))
app.get('/dizia/', (req, res) => res.send('Welcome to AI-DIZITAL - Blockchian APIs - for details: Contact@ravichand.m@aidizital.com'))
//
// getBlocks,
// getChaincode,
// getChannel,
// getOrderer,
// getPeer,
// getPeer_ref_chaincode,
// getPeer_ref_channel,
// getTransactions,
// getWrite_lock
//
app.get('/dizia/blocks', (req, res) => main.getBlocks(req, res, db))
app.get('/dizia/chaincodes', (req, res) => main.getChaincode(req, res, db))
app.get('/dizia/channel', (req, res) => main.getChannel(req, res, db))
app.get('/dizia/orderer', (req, res) => main.getOrderer(req, res, db))
app.get('/dizia/peer', (req, res) => main.getPeer(req, res, db))
app.get('/dizia/peer_ref_chaincode', (req, res) => main.getPeer_ref_chaincode(req, res, db))
app.get('/dizia/peer_ref_channel', (req, res) => main.getPeer_ref_channel(req, res, db))
app.get('/dizia/transactions', (req, res) => main.getTransactions(req, res, db))
app.get('/dizia/transbyblocks', (req, res) => main.getTransbyblocks(req, res, db))
app.get('/dizia/write_lock', (req, res) => main.getWrite_lock(req, res, db))
// Setting for Hyperledger Fabric
const { FileSystemWallet, Gateway } = require('fabric-network');
const path = require('path');
//const ccpPath = path.resolve(__dirname, '..', '..', 'dizitrade-jutebag', 'connection-manufacturer.json');
app.use(cors());
//queryAllUsers
app.get('/api/queryAllAssets', async function (req, res) {
    try {

        const ccpPath = path.resolve(__dirname, '..', 'connections', 'connection-manufacturer.json');
        // Create a new file system based wallet for managing identities.
        const walletPath = path.join(process.cwd(), `wallet/manufacturer`);
        const wallet = new FileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        // Check to see if we've already enrolled the user.
        const userExists = await wallet.exists('User1');
        if (!userExists) {
            console.log('An identity for the user "User1" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        // Create a new gateway for connecting to our peer node.
        const gateway = new Gateway();
        await gateway.connect(ccpPath, { wallet, identity: 'User1', discovery: { enabled: true, asLocalhost: true } });

        // Get the network (channel) our contract is deployed to.
        const network = await gateway.getNetwork('supplychainchannel');

        // Get the contract from the network.
        const contract = network.getContract('pharma-ccv01');

        // Evaluate the specified transaction.
        // queryAllAsset transaction - requires no arguments, ex: ('queryAllAsset')
        const result = await contract.evaluateTransaction('queryAllAssets', 'PhAsset')
        //console.log(`Transaction has been evaluated, result is: ${result.toString()}`);
	const result1 = result.toString();
        res.status(200).json({response: result1});

    } catch (error) {
        console.error(`Failed to evaluate transaction: ${error}`);
        res.status(500).json({error: error});
        process.exit(1);
    }
});

app.get('/api/queryAllUsers', async function (req, res) {
    try {

        const ccpPath = path.resolve(__dirname, '..', 'connections', 'connection-manufacturer.json');
        // Create a new file system based wallet for managing identities.
        const walletPath = path.join(process.cwd(), `wallet/manufacturer`);
        const wallet = new FileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        // Check to see if we've already enrolled the user.
        const userExists = await wallet.exists('User1');
        if (!userExists) {
            console.log('An identity for the user "User1" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        // Create a new gateway for connecting to our peer node.
        const gateway = new Gateway();
        await gateway.connect(ccpPath, { wallet, identity: 'User1', discovery: { enabled: true, asLocalhost: true } });

        // Get the network (channel) our contract is deployed to.
        const network = await gateway.getNetwork('supplychainchannel');

        // Get the contract from the network.
        const contract = network.getContract('pharma-ccv01');

        // Evaluate the specified transaction.
        // queryAllAsset transaction - requires no arguments, ex: ('queryAllAsset')
        const result = await contract.evaluateTransaction('queryAllUsers', 'PhAsset')
        //console.log(`Transaction has been evaluated, result is: ${result.toString()}`);
	const result1 = result.toString();
        res.status(200).json({response: result1});

    } catch (error) {
        console.error(`Failed to evaluate transaction: ${error}`);
        res.status(500).json({error: error});
        process.exit(1);
    }
});

app.get('/api/queryAsset/:assetId', async function (req, res) {
    try {

        // Create a new file system based wallet for managing identities.
        //const ccpPath = path.resolve(__dirname, '..', 'connections', 'connection-wholesaler.json');
        const ccpPath = path.resolve(__dirname, '..', 'connections', 'connection-manufacturer.json');
        const walletPath = path.join(process.cwd(), `wallet/manufacturer`);
        const wallet = new FileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        // Check to see if we've already enrolled the user.
        const userExists = await wallet.exists('User1');
        if (!userExists) {
            console.log('An identity for the user "User1" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        // Create a new gateway for connecting to our peer node.
        const gateway = new Gateway();
        await gateway.connect(ccpPath, { wallet, identity: 'User1', discovery: { enabled: true, asLocalhost: true } });

        // Get the network (channel) our contract is deployed to.
        const network = await gateway.getNetwork('supplychainchannel');

        // Get the contract from the network.
        const contract = network.getContract('pharma-ccv01');

	console.log(`[RC] I am in the queryAsset: ${req.params.assetId}`);
        // Evaluate the specified transaction.
	const result = await contract.evaluateTransaction('queryAsset', req.params.assetId);
        //const result = await contract.evaluateTransaction('queryAsset', 'PhAsset1');
	console.log(`Transaction has been evaluated, result is: ${result.toString()}`);
	res.status(200).json({response: result.toString()});


    } catch (error) {
	console.error(`Failed to evaluate transaction: ${error}`);
        res.status(500).json({error: error});
        process.exit(1);
    }
});

app.get('/api/getHistoryByPhAssetId/:assetId', async function (req, res) {
    try {

        // Create a new file system based wallet for managing identities.
        //const ccpPath = path.resolve(__dirname, '..', 'connections', 'connection-wholesaler.json');
        const ccpPath = path.resolve(__dirname, '..', 'connections', 'connection-manufacturer.json');
        const walletPath = path.join(process.cwd(), `wallet/manufacturer`);
        const wallet = new FileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        // Check to see if we've already enrolled the user.
        const userExists = await wallet.exists('User1');
        if (!userExists) {
            console.log('An identity for the user "User1" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        // Create a new gateway for connecting to our peer node.
        const gateway = new Gateway();
        await gateway.connect(ccpPath, { wallet, identity: 'User1', discovery: { enabled: true, asLocalhost: true } });

        // Get the network (channel) our contract is deployed to.
        const network = await gateway.getNetwork('supplychainchannel');

        // Get the contract from the network.
        const contract = network.getContract('pharma-ccv01');

	console.log(`[RC] I am in the queryAsset: ${req.params.assetId}`);
        // Evaluate the specified transaction.
	const result = await contract.evaluateTransaction('getHistoryByPhAssetId', req.params.assetId);
        //const result = await contract.evaluateTransaction('queryAsset', 'PhAsset1');
	console.log(`Transaction has been evaluated, result is: ${result.toString()}`);
	res.status(200).json({response: result.toString()});


    } catch (error) {
	console.error(`Failed to evaluate transaction: ${error}`);
        res.status(500).json({error: error});
        process.exit(1);
    }
});

app.post('/api/addAsset/', async function (req, res) {
    try {

        // Create a new file system based wallet for managing identities.
        const ccpPath = path.resolve(__dirname, '..', 'connections', 'connection-manufacturer.json');
        //const walletPath = path.join(process.cwd(), 'wallet');
        const walletPath = path.join(process.cwd(), `wallet/manufacturer`);
        const wallet = new FileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        // Check to see if we've already enrolled the user.
        const userExists = await wallet.exists('User1');
        if (!userExists) {
            console.log('An identity for the user "User1" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        // Create a new gateway for connecting to our peer node.
        const gateway = new Gateway();
        await gateway.connect(ccpPath, { wallet, identity: 'User1', discovery: { enabled: true, asLocalhost: true } });

        // Get the network (channel) our contract is deployed to.
        const network = await gateway.getNetwork('supplychainchannel');

        // Get the contract from the network.
        const contract = network.getContract('pharma-ccv01');

        // Submit the specified tranansaction
await contract.submitTransaction('createPhAsset', "User1", req.body.QRCode, req.body.BatchNo, req.body.OrderNo, req.body.AssetName, req.body.AssetType, req.body.AssetQty, req.body.DateWhen, req.body.ExpiryDate, req.body.OwnerWho, req.body.GpslocWhere, req.body.TransWhy, req.body.AssetStatus);
        //console.log('Transaction has been submitted');
        res.send('Transaction has been submitted');
	//res.status(200).json({response: result.toString()});
        // const assetinfo = result;//jutebagasset.JAsset_Id 
        // Get latest transaction ID  
        // Get transbyblock 
        // Disconnect from the gateway.
        await gateway.disconnect();

    } catch (error) {
        console.error(`Failed to submit transaction: ${error}`);
        process.exit(1);
    }

});

//Update Asset can be done by Manufacturer, Wholesalers and Pharmacy
//General Update used for Manufactuerer  - Manufacturer
//User1: Manufacturer
//User2: QC
//User3: Logistics
//User4: Pharmacy
//User5:Distributor 
//user6: Pharmacy
app.post('/api/updatePhAsset/', async function (req, res) {
    try {
	    //RaviChand on 16-Oct-2020
	    // smart contract actions as per the orgs
	    // Manufactuer : User1-Production Manager Creates Assets , User2-QC
	    // AssetHolders: Use3-Logistics, User4-Wholesalers/Distributors
	    // Pharma: User5:Dispanser Pharmacist
        const orguser = req.body.UserId;

        var ccpPath = "";
        var walletPath = "";
	if (orguser == ('User1' || 'User2')){
		// Create a new file system based wallet for managing identities.
		 ccpPath = path.resolve(__dirname, '..', 'connections', 'connection-manufacturer.json');
		 walletPath = path.join(process.cwd(), `wallet/manufacturer`);
	}
	else if (orguser == ('User3' || 'User4')){
		// Create a new file system based wallet for managing identities.
		ccpPath = path.resolve(__dirname, '..', 'connections', 'connection-assetholder.json');
		walletPath = path.join(process.cwd(), `wallet/assetholder`);
	}
	else if (orguser == ('User5')){
        // Create a new file system based wallet for managing identities.
        ccpPath = path.resolve(__dirname, '..', 'connections', 'connection-pharmacy.json');
        walletPath = path.join(process.cwd(), `wallet/pharmacy`);
        }
        const wallet = new FileSystemWallet(walletPath);
        //console.log(`Wallet path: ${walletPath}`);
        console.log(`ccPath path: ${ccpPath}`);
        //console.log(`wallet path: ${wallet}`);
        //process.exit(1);
        // Check to see if we've already enrolled the user.
        const userExists = await wallet.exists(orguser);
        if (!userExists) {
            console.log('An identity for the user "user" does not exist in the wallet User:'+orguser);
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        // Create a new gateway for connecting to our peer node.
        const gateway = new Gateway();
        await gateway.connect(ccpPath, { wallet, identity: orguser, discovery: { enabled: true, asLocalhost: true } });

        // Get the network (channel) our contract is deployed to.
        const network = await gateway.getNetwork('supplychainchannel');

        // Get the contract from the network.
        const contract = network.getContract('pharma-ccv01');
        // Submit the specified tranansaction
	//User1: Manufacturer
	//User2: Quality
	//User3: Logistics 
        //User4: Pharmacy
        //User5: Ricemill
   //await contract.submitTransaction('updatePhAsset',req.body.PhAssetId,req.body.UserId,req.body.DateWhen,req.body.OwnerWho,req.body.GpslocWhere, req.body.TransWhy, req.body.AssetStatus);
console.log("RC-Check: "+req.body.PhAssetId+","+req.body.UserId+","+req.body.DateWhen+","+req.body.TransWhy+","+req.body.OwnerWho+","+req.body.GpslocWhere+","+req.body.AssetStatus);
await contract.submitTransaction('updatePhAsset', req.body.PhAssetId,req.body.UserId, req.body.DateWhen, req.body.TransWhy, req.body.OwnerWho, req.body.GpslocWhere,  req.body.AssetStatus);
        console.log('Asset Transaction has been submitted');
        res.send('Asset Update Transaction has been submitted');

        // Disconnect from the gateway.
        await gateway.disconnect();

    } catch (error) {
        console.error(`Failed to submit transaction: ${error}`);
        process.exit(1);
    }
})
//Update Asset Wholesaler 
app.post('/api/updatePhAssetbyAH/', async function (req, res) {
    try {

        // Create a new file system based wallet for managing identities.
        const ccpPath = path.resolve(__dirname, '..', 'connections', 'connection-assetholder.json');
        //const contract = await fabricNetwork.connectNetwork('connection-manufacturer.json', 'wallet/wallet-manufacturer');
        //const walletPath = path.join(process.cwd(), 'wallet');
        const walletPath = path.join(process.cwd(), `wallet/assetholder`);
        const wallet = new FileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        // Check to see if we've already enrolled the user.
        const userExists = await wallet.exists('user4');
        if (!userExists) {
            console.log('An identity for the user "User1" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        // Create a new gateway for connecting to our peer node.
        const gateway = new Gateway();
        await gateway.connect(ccpPath, { wallet, identity: 'user4', discovery: { enabled: true, asLocalhost: true } });

        // Get the network (channel) our contract is deployed to.
        const network = await gateway.getNetwork('supplychainchannel');

        // Get the contract from the network.
        const contract = network.getContract('pharma-ccv01');
        // Submit the specified tranansaction
	//User1: Manufacturer
	//User2: Quality
	//User3: Logistics 
        //User4: Pharmacy
        //User5: Ricemill
        await contract.submitTransaction('updatePhAsset', req.body.PhAssetId, req.body.DateWhen, req.body.OwnerWho, req.body.GpslocWhere, req.body.TransWhy, req.body.AssetStatus);
        console.log('Asset Transaction has been submitted');
        res.send('Asset Update Transaction has been submitted');

        // Disconnect from the gateway.
        await gateway.disconnect();

    } catch (error) {
        console.error(`Failed to submit transaction: ${error}`);
        process.exit(1);
    }
})
//Update Asset can be done by Manufacturer, Wholesalers and Pharmacy
app.post('/api/updatePhAssetPh/', async function (req, res) {
    try {

        // Create a new file system based wallet for managing identities.
        const ccpPath = path.resolve(__dirname, '..', 'connections', 'connection-pharmacy.json');
        //const contract = await fabricNetwork.connectNetwork('connection-manufacturer.json', 'wallet/wallet-manufacturer');
        //const walletPath = path.join(process.cwd(), 'wallet');
        const walletPath = path.join(process.cwd(), `wallet/pharmacy`);
        const wallet = new FileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        // Check to see if we've already enrolled the user.
        const userExists = await wallet.exists('user5');
        if (!userExists) {
            console.log('An identity for the user "user5" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        // Create a new gateway for connecting to our peer node.
        const gateway = new Gateway();
        await gateway.connect(ccpPath, { wallet, identity: 'user5', discovery: { enabled: true, asLocalhost: true } });

        // Get the network (channel) our contract is deployed to.
        const network = await gateway.getNetwork('supplychainchannel');

        // Get the contract from the network.
        const contract = network.getContract('pharma-ccv01');
        // Submit the specified tranansaction
	//User1: Manufacturer
	//User2: Quality
	//User3: Logistics 
        //User4: Pharmacy
        //User5: Ricemill
        await contract.submitTransaction('updatePhAsset', req.body.PhAssetId, req.body.DateWhen, req.body.OwnerWho, req.body.GpslocWhere, req.body.TransWhy, req.body.AssetStatus);
        console.log('Asset Transaction has been submitted');
        res.send('Asset Update Transaction has been submitted');

        // Disconnect from the gateway.
        await gateway.disconnect();

    } catch (error) {
        console.error(`Failed to submit transaction: ${error}`);
        process.exit(1);
    }
})

// App Server Connection
 app.listen(process.env.PORT || 8080, () => {
   console.log(`app is running on port ${process.env.PORT || 8080}`)
  })
