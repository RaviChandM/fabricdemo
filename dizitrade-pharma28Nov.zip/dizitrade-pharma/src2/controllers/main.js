// Hello Below are the APIs newlly added to give clear picture on Blocks and Transactions
// RaviChand Matangi 03-Aug-2020
//app.get('/dizia/blocks', (req, res) => main.getTableData(req, res, db)) 
//app.get('/dizia/chaincode', (req, res) => main.getTableData(req, res, db))
//app.get('/dizia/channel', (req, res) => main.getTableData(req, res, db))
//app.get('/dizia/orderer', (req, res) => main.getTableData(req, res, db))
//app.get('/dizia/peer', (req, res) => main.getTableData(req, res, db))
//app.get('/dizia/peer_ref_chaincode', (req, res) => main.getTableData(req, res, db))
//app.get('/dizia/peer_ref_channel', (req, res) => main.getTableData(req, res, db)) 
//app.get('/dizia/transactions', (req, res) => main.getTableData(req, res, db))
//app.get('/dizia/write_lock', (req, res) => main.getTableData(req, res, db)) 
//
const getBlocks = (req, res, db) => {
	db.select('*').from('blocks')
		.then(items => {
			if(items.length){
				res.json(items)
			} else {
				res.json({dataExists: 'false'})
			}
		})
		.catch(err => res.status(400).json({dbError: 'db error'}))
}

const getChaincode = (req, res, db) => {
	db.select('*').from('chaincodes')
		.then(items => {
			if(items.length){
				res.json(items)
			} else {
				res.json({dataExists: 'false'})
			}
		})
		.catch(err => res.status(400).json({dbError: 'db error'}))
}
const getChannel = (req, res, db) => {
	db.select('*').from('channel')
		.then(items => {
			if(items.length){
				res.json(items)
			} else {
				res.json({dataExists: 'false'})
			}
		})
		.catch(err => res.status(400).json({dbError: 'db error'}))
}
const getOrderer = (req, res, db) => {
	db.select('*').from('orderer')
		.then(items => {
			if(items.length){
				res.json(items)
			} else {
				res.json({dataExists: 'false'})
			}
		})
		.catch(err => res.status(400).json({dbError: 'db error'}))
}

const getPeer = (req, res, db) => {
	db.select('*').from('peer')
		.then(items => {
			if(items.length){
				res.json(items)
			} else {
				res.json({dataExists: 'false'})
			}
		})
		.catch(err => res.status(400).json({dbError: 'db error'}))
}

const getPeer_ref_chaincode = (req, res, db) => {
	db.select('*').from('peer_ref_chaincode')
		.then(items => {
			if(items.length){
				res.json(items)
			} else {
				res.json({dataExists: 'false'})
			}
		})
		.catch(err => res.status(400).json({dbError: 'db error'}))
}

const getPeer_ref_channel = (req, res, db) => {
	db.select('*').from('peer_ref_channel')
		.then(items => {
			if(items.length){
				res.json(items)
			} else {
				res.json({dataExists: 'false'})
			}
		})
		.catch(err => res.status(400).json({dbError: 'db error'}))
}
const getTransactions = (req, res, db) => {
	db.select('*').from('transactions')
		.then(items => {
			if(items.length){
				res.json(items)
			} else {
				res.json({dataExists: 'false'})
			}
		})
		.catch(err => res.status(400).json({dbError: 'db error'}))
}
const getTransbyblocks = (req, res, db) => {
	db.select('*').from('transbyblock')
		.then(items => { 
			if(items.length){ 
				res.json(items)
			} else { 
				res.json({dataExists: 'false'}) 
			} 
		}) 
		.catch(err => res.status(400).json({dbError: 'db error'}))
}


const getWrite_lock = (req, res, db) => {
	db.select('*').from('write_lock')
		.then(items => {
			if(items.length){
				res.json(items)
			} else {
				res.json({dataExists: 'false'})
			}
		})
		.catch(err => res.status(400).json({dbError: 'db error'}))
}


module.exports = {
	getBlocks,
	getChaincode,
	getChannel,
	getOrderer,
	getPeer,
	getPeer_ref_chaincode,
	getPeer_ref_channel,
	getTransactions,
	getTransbyblocks,
	getWrite_lock
	
}
