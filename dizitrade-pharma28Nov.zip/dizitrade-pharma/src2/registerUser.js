/*
 * SPDX-License-Identifier: Apache-2.0
 */

'use strict';

const { FileSystemWallet, Gateway, X509WalletMixin } = require('fabric-network');
const path = require('path');


async function main() {
    try {

        const ccpPath = path.resolve(__dirname, '..', 'connections', 'connection-manufacturer.json');
        // Create a new file system based wallet for managing identities.
        const walletPath = path.join(process.cwd(), `wallet/manufacturer`);
        const wallet = new FileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        // Check to see if we've already enrolled the user.
        const userExists = await wallet.exists('User1');
        if (userExists) {
            console.log('An identity for the user "User1" already exists in the wallet');
            //return;
        }

        // Check to see if we've already enrolled the admin user.
        const adminExists = await wallet.exists('admin');
        if (!adminExists) {
            console.log('An identity for the admin user "admin" does not exist in the wallet');
            console.log('Run the enrollAdmin.js application before retrying');
            return;
        }

        // Create a new gateway for connecting to our peer node.
        const gateway = new Gateway();
        await gateway.connect(ccpPath, { wallet, identity: 'admin', discovery: { enabled: true, asLocalhost: true } });
        // Get the CA client object from the gateway for interacting with the CA.
        const ca = gateway.getClient().getCertificateAuthority();
        const adminIdentity = gateway.getCurrentIdentity();
        // Register the user, enroll the user, and import the new identity into the wallet.
        const secret = await ca.register({ affiliation: '', enrollmentID: 'User1', role: 'client' }, adminIdentity);
        const enrollment = await ca.enroll({ enrollmentID: 'User1', enrollmentSecret: secret });
        const userIdentity = X509WalletMixin.createIdentity('ManufacturerMSP', enrollment.certificate, enrollment.key.toBytes());
        await wallet.import('User1', userIdentity);
        console.log('Successfully registered and enrolled admin user "User1" and imported it into the wallet');

    } catch (error) {
        console.error(`Failed to register user "User1": ${error}`);
        process.exit(1);
    }

    try {

        const ccpPath = path.resolve(__dirname, '..', 'connections', 'connection-manufacturer.json');
        // Create a new file system based wallet for managing identities.
        const walletPath = path.join(process.cwd(), `wallet/manufacturer`);
        const wallet = new FileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        // Check to see if we've already enrolled the user.
        const userExists = await wallet.exists('User2');
        if (userExists) {
            console.log('An identity for the user "User2" already exists in the wallet');
            //return;
        }

        // Check to see if we've already enrolled the admin user.
        const adminExists = await wallet.exists('admin');
        if (!adminExists) {
            console.log('An identity for the admin user "admin" does not exist in the wallet');
            console.log('Run the enrollAdmin.js application before retrying');
            return;
        }

        // Create a new gateway for connecting to our peer node.
        const gateway = new Gateway();
        await gateway.connect(ccpPath, { wallet, identity: 'admin', discovery: { enabled: true, asLocalhost: true } });
        // Get the CA client object from the gateway for interacting with the CA.
        const ca = gateway.getClient().getCertificateAuthority();
        const adminIdentity = gateway.getCurrentIdentity();
        // Register the user, enroll the user, and import the new identity into the wallet.
        const secret = await ca.register({ affiliation: '', enrollmentID: 'User2', role: 'client' }, adminIdentity);
        const enrollment = await ca.enroll({ enrollmentID: 'User2', enrollmentSecret: secret });
        const userIdentity = X509WalletMixin.createIdentity('ManufacturerMSP', enrollment.certificate, enrollment.key.toBytes());
        await wallet.import('User2', userIdentity);
        console.log('Successfully registered and enrolled admin user "User2" and imported it into the wallet');

    } catch (error) {
        console.error(`Failed to register user "User2": ${error}`);
        process.exit(1);
    }

    try {

        const ccpPath = path.resolve(__dirname, '..', 'connections', 'connection-assetholder.json');
        // Create a new file system based wallet for managing identities.
        const walletPath = path.join(process.cwd(), `wallet/assetholder`);
        const wallet = new FileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        // Check to see if we've already enrolled the user.
        const userExists = await wallet.exists('User3');
        if (userExists) {
            console.log('An identity for the user "User3" already exists in the wallet');
            return;
        }

        // Check to see if we've already enrolled the admin user.
        const adminExists = await wallet.exists('admin');
        if (!adminExists) {
            console.log('An identity for the admin user "admin" does not exist in the wallet');
            console.log('Run the enrollAdmin.js application before retrying');
            return;
        }

        // Create a new gateway for connecting to our peer node.
        const gateway = new Gateway();
        await gateway.connect(ccpPath, { wallet, identity: 'admin', discovery: { enabled: true, asLocalhost: true } });

        // Get the CA client object from the gateway for interacting with the CA.
        const ca = gateway.getClient().getCertificateAuthority();
        const adminIdentity = gateway.getCurrentIdentity();

        // Register the user, enroll the user, and import the new identity into the wallet.
        const secret = await ca.register({ affiliation: '', enrollmentID: 'User3', role: 'client' }, adminIdentity);
        const enrollment = await ca.enroll({ enrollmentID: 'User3', enrollmentSecret: secret });
        const userIdentity = X509WalletMixin.createIdentity('AssetHolderMSP', enrollment.certificate, enrollment.key.toBytes());
        await wallet.import('User3', userIdentity);
        console.log('Successfully registered and enrolled admin user "User3" and imported it into the wallet');


        // Check to see if we've already enrolled the user.
        const userExists4 = await wallet.exists('User4');
        if (userExists4) {
            console.log('An identity for the user "User4" already exists in the wallet');
            return;
        }

        // Check to see if we've already enrolled the admin user.
        const adminExists4 = await wallet.exists('admin');
        if (!adminExists4) {
            console.log('An identity for the admin user "admin" does not exist in the wallet');
            console.log('Run the enrollAdmin.js application before retrying');
            return;
        }

        // Create a new gateway for connecting to our peer node.
        const gateway4 = new Gateway();
        await gateway4.connect(ccpPath, { wallet, identity: 'admin', discovery: { enabled: true, asLocalhost: true } });

        // Get the CA client object from the gateway for interacting with the CA.
        const ca4 = gateway4.getClient().getCertificateAuthority();
        const adminIdentity4 = gateway4.getCurrentIdentity();

        // Register the user, enroll the user, and import the new identity into the wallet.
        const secret4 = await ca4.register({ affiliation: '', enrollmentID: 'User4', role: 'client' }, adminIdentity);
        const enrollment4 = await ca4.enroll({ enrollmentID: 'User4', enrollmentSecret: secret4 });
        const userIdentity4 = X509WalletMixin.createIdentity('AssetHolderMSP', enrollment4.certificate, enrollment4.key.toBytes());
        await wallet.import('User4', userIdentity4);
        console.log('Successfully registered and enrolled admin user "User4" and imported it into the wallet');

    } catch (error) {
        console.error(`Failed to register user "User3 or User4": ${error}`);
        //process.exit(1);
    }

    try {

        const ccpPath = path.resolve(__dirname, '..', 'connections', 'connection-pharmacy.json');
        // Create a new file system based wallet for managing identities.
        const walletPath = path.join(process.cwd(), `wallet/pharmacy`);
        const wallet = new FileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        // Check to see if we've already enrolled the user.
        const userExists = await wallet.exists('User5');
        if (userExists) {
            console.log('An identity for the user "User5" already exists in the wallet');
            return;
        }

        // Check to see if we've already enrolled the admin user.
        const adminExists = await wallet.exists('admin');
        if (!adminExists) {
            console.log('An identity for the admin user "admin" does not exist in the wallet');
            console.log('Run the enrollAdmin.js application before retrying');
            return;
        }

        // Create a new gateway for connecting to our peer node.
        const gateway = new Gateway();
        await gateway.connect(ccpPath, { wallet, identity: 'admin', discovery: { enabled: true, asLocalhost: true } });

        // Get the CA client object from the gateway for interacting with the CA.
        const ca = gateway.getClient().getCertificateAuthority();
        const adminIdentity = gateway.getCurrentIdentity();

        // Register the user, enroll the user, and import the new identity into the wallet.
        const secret = await ca.register({ affiliation: '', enrollmentID: 'User5', role: 'client' }, adminIdentity);
        const enrollment = await ca.enroll({ enrollmentID: 'User5', enrollmentSecret: secret });
        const userIdentity = X509WalletMixin.createIdentity('PharmacyMSP', enrollment.certificate, enrollment.key.toBytes());
//fabric-ca-client register --id.name User2 --id.secret User2pw --id.type user --id.affiliation org1 --id.attrs 'app1Admin=true:ecert,email=User2@gmail.com'
        await wallet.import('User5', userIdentity);
        console.log('Successfully registered and enrolled admin user "User5" and imported it into the wallet');

    } catch (error) {
        console.error(`Failed to register user "User5": ${error}`);
        //process.exit(1);
    }
}

main();
