#!/bin/bash
#
# Exit on first error, print all commands
set -e

echo "======================================== Removing volumes =========================================================="
echo ""
# Shut down the Docker containers for the system tests.
docker-compose -f artifacts/docker-compose.yaml -f artifacts/docker-compose-couch.yaml down -v
#docker-conpose -f artifacts/docker-compose-couch.yaml down -v

rm -fr artifacts/network
docker rm $(docker ps -aq)
docker kill $(docker ps -aq)
docker rmi $(docker images \"*pharma*\" -q)
# remove the local store
echo ""
# Your system is now clean
docker ps
echo ""
echo "===================================== Removed volumes successfully ================================================="
