var express = require('express');
var bodyParser = require('body-parser');
var app = express();
const fabricNetwork = require('./fabricNetwork')
app.set('view engine', 'ejs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: true
}));


app.post('/api/createJbAsset', async function (req, res) {

  try {
    const contract = await fabricNetwork.connectNetwork('connection-jutemill.json', 'wallet/jutemill');
    let JbAsset = {
      name: req.body.name, // pass QR code here
      //latitude: req.body.latitude,
      //longitude: req.body.longitude,
      batchid: req.body.batchid,
      orderid: req.body.orderid,
      jutemillid: req.body.jutemillid,
      warehouseid: req.body.warehouseid,
      status: req.body.status
    }
    let tx = await contract.submitTransaction('createJbAsset', JSON.stringify(JbAsset));
    res.json({
      status: 'OK - Transaction has been submitted',
      txid: tx.toString()
    });
  } catch (error) {
    console.error(`Failed to evaluate transaction: ${error}`);
    res.status(500).json({
      error: error
    });
  }

});

app.get('/api/queryAsset/:id', async function (req, res) {
  try {
    const contract = await fabricNetwork.connectNetwork('connection-assetholder.json', 'wallet/assetholder');
    const result = await contract.evaluateTransaction('queryAsset', req.params.id.toString());
    let response = JSON.parse(result.toString());
    res.json({result:response});
  } catch (error) {
    console.error(`Failed to evaluate transaction: ${error}`);
    res.status(500).json({
      error: error
    });
  }
})


app.post('/api/setPosition', async function (req, res) {

  try {
    const contract = await fabricNetwork.connectNetwork('connection-assetholder.json', 'wallet/assetholder');
    let tx = await contract.submitTransaction('setPosition', req.body.id.toString(), req.body.latitude.toString(), req.body.longitude.toString());
    res.json({
      status: 'OK - Transaction has been submitted',
      txid: tx.toString()
    });
  } catch (error) {
    console.error(`Failed to evaluate transaction: ${error}`);
    res.status(500).json({
      error: error
    });
  }

});


app.post('/api/queryAllAsset', async function (req, res) {
  try {
    const contract = await fabricNetwork.connectNetwork('connection-jutemill.json', 'wallet/jutemill');
    const result = await contract.evaluateTransaction('queryAllAsset', 'JbAsset');
    console.log(`Transaction has been evaluated, result is: ${result.toString()}`);	  
  } catch (error) {
    console.error(`Failed to evaluate transaction: ${error}`);
    res.status(500).json({
      error: error
    });
  }

})


app.listen(3000, ()=>{
  console.log("***********************************");
  console.log("API server listening at localhost:3000");
  console.log("***********************************");
});
